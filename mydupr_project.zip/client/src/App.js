import React, { useState, useEffect } from 'react';
import axios from 'axios';

// Import CSS file
import './styles.css';

function App() {
    const [players, setPlayers] = useState([]);

    useEffect(() => {
        axios.get('/api/players')
            .then(response => setPlayers(response.data))
            .catch(error => console.error('Error fetching players:', error));
    }, []);

    return (
        <div className="app-container">
            <h1>MyDUPR Player List</h1>
            <ul>
                {players.map(player => (
                    <li key={player.id}>{player.name} - Rating: {player.rating}</li>
                ))}
            </ul>
        </div>
    );
}

export default App;

